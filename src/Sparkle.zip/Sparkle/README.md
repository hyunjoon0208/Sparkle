## 2023 동계 혁신융합대학 가상환경기반 자율주행 경진대회

팀 이름 : Sparkle

수상 : (예정)



## 팀원
- 장정안 (팀장, SLAM)
- 성창엽 (LiDAR)
- 이은선 (LiDAR)
- 변준형 (Camera)
- 조현준 (Camera)

## 대회 포스터
![RUiRQNhTyBVuRTQEZmcgHasBYo](https://github.com/hyunjoon0208/Sparkle/assets/54919634/a663e428-9e5a-4a23-a8f2-bd1b017eab8f)
